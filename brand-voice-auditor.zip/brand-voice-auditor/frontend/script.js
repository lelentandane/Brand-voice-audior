(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const form = $("audit-form");
  const submitBtn = $("submit-btn");
  const loadingBox = $("loading");
  const loadingText = $("loading-text");
  const errorBox = $("error");
  const results = $("results");

  const LOADING_STEPS = [
    "Fetching the page...",
    "Auditing brand voice...",
    "Analyzing color palettes...",
    "Evaluating SEO...",
    "Putting the report together...",
  ];
  const TIMEOUT_MS = 90000;
  const HEX_RE = /^#[0-9a-f]{6}$/i;

  // ---------- safe DOM helpers ----------
  // All report text comes from third-party sites or an LLM, so it is only
  // ever inserted with textContent. Never use innerHTML here.
  function h(tag, opts = {}, ...children) {
    const node = document.createElement(tag);
    if (opts.class) node.className = opts.class;
    if (opts.text !== undefined) node.textContent = opts.text;
    if (opts.attrs) {
      for (const [k, v] of Object.entries(opts.attrs)) node.setAttribute(k, v);
    }
    for (const child of children) if (child) node.append(child);
    return node;
  }

  const tone = (n) => (n === null || n === undefined ? "none" : n >= 80 ? "good" : n >= 60 ? "ok" : "poor");

  function ring(value) {
    const node = h("div", { class: `ring ${tone(value)}` }, h("span", { text: value ?? "-" }));
    node.style.setProperty("--pct", value ?? 0);
    return node;
  }

  function bar(label, value, emptyNote) {
    const hasValue = value !== null && value !== undefined;
    const row = h("div", { class: `bar-row ${tone(value)}` });
    row.append(
      h("div", { class: "bar-label" },
        h("span", { text: label }),
        h("span", { class: hasValue ? "val" : "val muted", text: hasValue ? `${value}/100` : emptyNote }))
    );
    const fill = h("div", { class: "bar-fill" });
    fill.style.width = `${hasValue ? value : 0}%`;
    row.append(h("div", { class: "bar-track" }, fill));
    return row;
  }

  function card(title, ...children) {
    return h("section", { class: "card" }, h("h2", { text: title }), ...children);
  }

  // ---------- renderers ----------
  function renderSummary(data) {
    const info = h("div", {},
      h("h2", { text: data.page.title || "Untitled page" }),
      h("p", { text: data.url }),
      h("p", { text: `${data.page.word_count} words, ${data.page.image_count} images` }));
    return h("section", { class: "card summary" }, ring(data.brand_health.overall), info);
  }

  function renderComponents(data) {
    const c = data.brand_health.components;
    return card("Brand health breakdown",
      bar("Brand voice", c.voice, "Not scored"),
      bar("SEO", c.seo, "Not scored"),
      bar("Visual cohesion", c.visual, "Not scored"));
  }

  function renderVoice(voice) {
    const body = [
      h("span", { class: "chip", text: voice.detected_tone }),
      bar("Consistency", voice.consistency_score, "Not scored"),
      bar("Guideline adherence", voice.guideline_adherence_score, "No guidelines given"),
      h("p", { text: voice.summary }),
    ];

    if (voice.strengths.length) {
      body.push(h("h3", { text: "Strengths" }),
        h("ul", {}, ...voice.strengths.map((s) => h("li", { text: s }))));
    }
    if (voice.issues.length) {
      body.push(h("h3", { text: "Issues and fixes" }));
      for (const issue of voice.issues) {
        body.push(h("div", { class: "issue" },
          h("strong", { text: issue.issue }),
          h("blockquote", { text: `"${issue.evidence}"` }),
          h("div", { class: "fix", text: `Fix: ${issue.fix}` })));
      }
    }
    return card("Brand voice", ...body);
  }

  function renderSeo(seo) {
    const list = h("ul", { class: "checks" }, ...seo.checks.map((c) =>
      h("li", { class: `check ${c.passed ? "pass" : "fail"}` },
        h("span", { class: "mark", text: c.passed ? "\u2713" : "\u2715",
                    attrs: { "aria-label": c.passed ? "Passed" : "Failed" } }),
        h("span", { text: c.check }),
        h("span", { class: "detail", text: c.detail }))));
    return card("SEO health", bar("SEO score", seo.score), list);
  }

  function swatch(color, small, note) {
    const hex = HEX_RE.test(color.hex) ? color.hex : "#888888";
    const colorBlock = h("div", { class: "color" });
    colorBlock.style.background = hex;
    const btn = h("button", { class: small ? "swatch small" : "swatch",
                              attrs: { type: "button", title: "Click to copy",
                                       "aria-label": `Copy ${hex}` } },
      colorBlock,
      h("div", { class: "meta" }, h("div", { class: "hex", text: hex }),
        note ? h("div", { class: "muted", text: note }) : null));
    btn.addEventListener("click", () => {
      if (navigator.clipboard) navigator.clipboard.writeText(hex).catch(() => {});
    });
    return btn;
  }

  function renderVisual(visual) {
    if (!visual) {
      return card("Color palette", h("p", { class: "muted", text: "Visual analysis was unavailable." }));
    }
    const body = [];
    if (visual.brand_palette.length) {
      body.push(h("div", { class: "palette" },
        ...visual.brand_palette.map((c) => swatch(c, false, `from ${c.sources.join(" + ")}`))));
      const m = visual.metrics;
      body.push(h("p", { class: "muted",
        text: `${m.palette_size} colors across ${m.hue_families} hue ${m.hue_families === 1 ? "family" : "families"}.` }));
    } else {
      body.push(h("p", { class: "muted", text: "No distinct brand colors were found." }));
    }
    if (visual.neutrals.length) {
      body.push(h("h3", { text: "Neutrals" }),
        h("div", { class: "palette" }, ...visual.neutrals.map((c) => swatch(c, true))));
    }
    return card("Color palette", ...body);
  }

  function render(data) {
    results.replaceChildren();
    for (const message of data.warnings) {
      results.append(h("div", { class: "banner warn", text: message }));
    }
    results.append(
      renderSummary(data),
      renderComponents(data),
      renderVoice(data.voice),
      renderSeo(data.seo),
      renderVisual(data.visual));
    results.hidden = false;
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- state helpers ----------
  let stepTimer = null;

  function setLoading(on) {
    submitBtn.disabled = on;
    loadingBox.hidden = !on;
    clearInterval(stepTimer);
    if (on) {
      let i = 0;
      loadingText.textContent = LOADING_STEPS[0];
      stepTimer = setInterval(() => {
        i = Math.min(i + 1, LOADING_STEPS.length - 1);
        loadingText.textContent = LOADING_STEPS[i];
      }, 2500);
    }
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function errorMessage(body, status) {
    if (body && typeof body.detail === "string") return body.detail;
    if (body && Array.isArray(body.detail) && body.detail.length) {
      return `Please check the form: ${body.detail[0].msg}.`;
    }
    return `The request failed (status ${status}).`;
  }

  // ---------- submit ----------
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    errorBox.hidden = true;

    const url = $("url").value.trim();
    if (!url) {
      showError("Enter a website address to audit.");
      $("url").focus();
      return;
    }

    const payload = { url };
    const tone_ = $("tone").value.trim();
    const guidelines = $("guidelines").value.trim();
    const keywords = $("keywords").value.split(",").map((k) => k.trim()).filter(Boolean).slice(0, 20);
    if (tone_) payload.brand_tone = tone_;
    if (guidelines) payload.guidelines = guidelines;
    if (keywords.length) payload.keywords = keywords;

    results.hidden = true;
    setLoading(true);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

    try {
      const res = await fetch("/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      let body = null;
      try { body = await res.json(); } catch { /* non-JSON error page */ }
      if (!res.ok) throw new Error(errorMessage(body, res.status));
      render(body);
    } catch (err) {
      if (err.name === "AbortError") showError("The audit took too long and was stopped. Try again.");
      else if (err instanceof TypeError) showError("Could not reach the server. Is the backend running?");
      else showError(err.message);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  });
})();
