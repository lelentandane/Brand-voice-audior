(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const form = $("audit-form");
  const submitBtn = $("submit-btn");
  const sampleBtn = $("sample-btn");
  const exampleBtn = $("example-btn");
  const loadingBox = $("loading");
  const loadingText = $("loading-text");
  const errorBox = $("error");
  const results = $("results");
  const statusEl = $("status");

  const LOADING_STEPS = [
    "Fetching the page...",
    "Reading your brand voice...",
    "Pulling colors from your styles and images...",
    "Checking SEO basics...",
    "Putting the report together...",
  ];
  const TIMEOUT_MS = 90000;
  const HEX_RE = /^#[0-9a-f]{6}$/i;
  const EXAMPLE_RULES = {
    tone: "warm, playful, premium",
    keywords: "specialty coffee, small batch",
    guidelines: "Short sentences. Friendly, never salesy. Say \"you\", not \"customers\".",
  };

  // All report text comes from third-party sites or an LLM, so it is only
  // ever inserted with textContent. Never use innerHTML here.
  function h(tag, opts = {}, ...children) {
    const node = document.createElement(tag);
    if (opts.class) node.className = opts.class;
    if (opts.text !== undefined) node.textContent = opts.text;
    if (opts.attrs) for (const [k, v] of Object.entries(opts.attrs)) node.setAttribute(k, v);
    for (const child of children) if (child) node.append(child);
    return node;
  }

  const tone = (n) => (n === null || n === undefined ? "none" : n >= 80 ? "good" : n >= 60 ? "ok" : "poor");

  function verdict(score) {
    if (score === null || score === undefined) return ["Not enough to score", "None of the checks could be scored for this page."];
    if (score >= 80) return ["Strong", "Your brand comes across clearly. The fixes below are polish."];
    if (score >= 60) return ["A good base with clear fixes", "The basics are there. The fixes below will make the biggest difference."];
    return ["Needs attention", "Visitors may get a mixed message. Start with the first fix below."];
  }

  function bar(label, value, emptyNote, note) {
    const hasValue = value !== null && value !== undefined;
    const row = h("div", { class: `bar-row ${tone(value)}` });
    row.append(h("div", { class: "bar-label" },
      h("span", { text: label }),
      h("span", { class: hasValue ? "val" : "val muted", text: hasValue ? `${value} out of 100` : emptyNote })));
    const fill = h("div", { class: "bar-fill" });
    fill.style.width = `${hasValue ? value : 0}%`;
    row.append(h("div", { class: "bar-track" }, fill));
    if (note) row.append(h("p", { class: "bar-note", text: note }));
    return row;
  }

  function block(title, intro, ...children) {
    return h("section", { class: "block" }, h("h3", { text: title }),
      intro ? h("p", { class: "explain", text: intro }) : null, ...children);
  }

  // ---------- renderers ----------
  function renderHead(data) {
    const head = h("header", { class: "report-head" });
    const palette = data.visual && data.visual.brand_palette ? data.visual.brand_palette : [];
    if (palette.length) {
      const strip = h("div", { class: "palette-strip", attrs: { role: "img", "aria-label": "Brand colors found on this site" } });
      for (const c of palette) {
        const part = h("div");
        part.style.background = HEX_RE.test(c.hex) ? c.hex : "#888888";
        part.style.flex = `${Math.max(Math.round((c.weight || 0.1) * 100), 10)} 1 0`;
        strip.append(part);
      }
      head.append(strip);
    }
    if (data.is_sample) head.append(h("span", { class: "badge", text: "Sample audit of a fictional brand" }));
    const title = h("h2", { text: data.page.title || "Untitled page", attrs: { tabindex: "-1", id: "report-title" } });
    head.append(title,
      h("p", { class: "meta", text: `${data.url} \u00b7 ${data.page.word_count} words, ${data.page.image_count} images` }));
    return head;
  }

  function renderVerdict(data) {
    const overall = data.brand_health.overall;
    const [headline, meaning] = verdict(overall);
    const wrap = h("section", { class: "verdict" },
      h("div", { class: `score-num ${tone(overall)}` },
        h("span", { text: overall === null ? "-" : String(overall) }), h("small", { text: "/100" })),
      h("div", {}, h("h3", { text: headline }), h("p", { text: meaning })));

    const fixes = data.priorities || [];
    if (fixes.length) {
      const list = h("ol");
      for (const f of fixes) {
        list.append(h("li", {}, h("div", { class: "area", text: f.area }),
          h("div", { class: "title", text: f.title }), h("p", { class: "action", text: f.action })));
      }
      wrap.append(h("div", { class: "fixes" }, h("h3", { text: `Fix these first (${fixes.length})` }), list));
    }
    return wrap;
  }

  function renderBreakdown(data) {
    const c = data.brand_health.components;
    const w = data.brand_health.weights;
    const pct = (k) => (w[k] ? ` Counts for ${Math.round(w[k] * 100)}% of the total.` : "");
    return block("Where the score comes from", "Three parts, each scored out of 100.",
      bar("Brand voice", c.voice, "Not scored", "How consistent and distinctive your writing sounds." + pct("voice")),
      bar("SEO basics", c.seo, "Not scored", "Whether search engines can understand the page." + pct("seo")),
      bar("Color cohesion", c.visual, "Not scored", "How focused your color palette is. Fewer color families scores higher." + pct("visual")));
  }

  function renderVoice(voice) {
    const body = [
      h("span", { class: "chip", text: voice.detected_tone }),
      h("p", { text: voice.summary }),
      bar("Consistency", voice.consistency_score, "Not scored", "Does the page sound like one brand from top to bottom?"),
      bar("Match to your rules", voice.guideline_adherence_score, "No rules given",
        voice.guideline_adherence_score === null ? "Add brand rules above to check this." : "How closely the page follows the rules you entered."),
    ];
    if (voice.strengths.length) {
      body.push(h("h4", { text: "What is working" }),
        h("ul", { class: "plain-list" }, ...voice.strengths.map((s) => h("li", { text: s }))));
    }
    if (voice.issues.length) {
      body.push(h("h4", { text: "Where the voice slips" }));
      for (const issue of voice.issues) {
        body.push(h("div", { class: "issue" },
          h("strong", { text: issue.issue }),
          h("blockquote", {}, h("mark", { text: issue.evidence })),
          h("div", { class: "fix" }, h("span", { text: "Try this: " }), document.createTextNode(issue.fix))));
      }
    }
    return block("Brand voice", null, ...body);
  }

  function renderSeo(seo) {
    const list = h("ul", { class: "checks" }, ...seo.checks.map((c) =>
      h("li", { class: c.passed ? "pass" : "fail" },
        h("span", { class: "mark", text: c.passed ? "\u2713" : "\u2715", attrs: { "aria-label": c.passed ? "Passed" : "Failed" } }),
        h("span", { text: c.check }),
        h("span", { class: "detail", text: c.detail }))));
    return block("SEO basics", "Simple checks that run the same way every time, so the same page always gets the same score.",
      bar("SEO score", seo.score), list);
  }

  const copied = h("p", { class: "copied", attrs: { "aria-live": "polite" } });

  function swatch(color, small, note) {
    const hex = HEX_RE.test(color.hex) ? color.hex : "#888888";
    const colorBlock = h("div", { class: "color" });
    colorBlock.style.background = hex;
    const btn = h("button", { class: small ? "swatch small" : "swatch",
      attrs: { type: "button", "aria-label": `Copy ${hex}` } },
      colorBlock, h("div", { class: "hex", text: hex }), note ? h("div", { class: "src", text: note }) : null);
    btn.addEventListener("click", () => {
      if (navigator.clipboard) navigator.clipboard.writeText(hex).catch(() => {});
      copied.textContent = `Copied ${hex}`;
    });
    return btn;
  }

  function renderVisual(visual) {
    if (!visual) {
      return block("Colors", null, h("p", { class: "explain", text: "Color analysis was unavailable for this page." }));
    }
    const body = [];
    if (visual.brand_palette.length) {
      const m = visual.metrics;
      body.push(h("div", { class: "palette" },
        ...visual.brand_palette.map((c) => swatch(c, false, `from ${c.sources.join(" and ")}`))));
      body.push(h("p", { class: "explain",
        text: `${m.palette_size} brand colors across ${m.hue_families} color ${m.hue_families === 1 ? "family" : "families"}. Click a color to copy it.` }));
    } else {
      body.push(h("p", { class: "explain", text: "No distinct brand colors were found." }));
    }
    if (visual.neutrals.length) {
      body.push(h("h4", { text: "Neutrals" }), h("div", { class: "palette" }, ...visual.neutrals.map((c) => swatch(c, true))));
    }
    body.push(copied);
    return block("Colors", "Read from your site's styles first, then from your images.", ...body);
  }

  function summaryText(data) {
    const lines = [`Brand health for ${data.url}: ${data.brand_health.overall}/100`];
    for (const f of data.priorities || []) lines.push(`- ${f.area}: ${f.title}. ${f.action}`);
    return lines.join("\n");
  }

  function renderActions(data) {
    const copyBtn = h("button", { class: "btn quiet", text: "Copy summary", attrs: { type: "button" } });
    copyBtn.addEventListener("click", () => {
      if (navigator.clipboard) navigator.clipboard.writeText(summaryText(data)).catch(() => {});
      copyBtn.textContent = "Copied";
    });
    const again = h("button", { class: "btn quiet", text: "Audit another site", attrs: { type: "button" } });
    again.addEventListener("click", () => { $("url").focus(); window.scrollTo({ top: 0 }); });
    return h("div", { class: "actions" }, copyBtn, again);
  }

  function renderHow() {
    return h("details", { class: "how" }, h("summary", { text: "How the score is worked out" }),
      h("p", { text: "Overall score = voice 50%, SEO 30%, color cohesion 20%. If a part cannot be measured, it is left out and the others are rescaled, not counted as zero." }),
      h("p", { text: "Voice is scored by an AI model against a fixed rubric. SEO is plain code. Color cohesion rewards palettes with fewer color families, so it understates brands that are colorful on purpose." }));
  }

  function render(data) {
    copied.textContent = "";
    results.replaceChildren();
    for (const message of data.warnings || []) results.append(h("div", { class: "banner warn", text: message }));
    results.append(renderHead(data), renderVerdict(data), renderBreakdown(data),
      renderVoice(data.voice), renderSeo(data.seo), renderVisual(data.visual), renderActions(data), renderHow());
    results.hidden = false;
    const t = $("report-title");
    t.scrollIntoView({ behavior: "smooth", block: "start" });
    t.focus({ preventScroll: true });
  }

  // ---------- state ----------
  let stepTimer = null;

  function setLoading(on, steps) {
    submitBtn.disabled = on;
    sampleBtn.disabled = on;
    loadingBox.hidden = !on;
    clearInterval(stepTimer);
    if (on) {
      let i = 0;
      loadingText.textContent = steps[0];
      stepTimer = setInterval(() => {
        i = Math.min(i + 1, steps.length - 1);
        loadingText.textContent = steps[i];
      }, 2500);
    }
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function errorMessage(body, status) {
    if (body && typeof body.detail === "string") return body.detail;
    if (body && Array.isArray(body.detail) && body.detail.length) return `Please check the form: ${body.detail[0].msg}.`;
    return `The request failed (status ${status}).`;
  }

  async function request(path, options, steps) {
    errorBox.hidden = true;
    results.hidden = true;
    setLoading(true, steps);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(path, { ...options, signal: controller.signal });
      let body = null;
      try { body = await res.json(); } catch { /* non-JSON error page */ }
      if (!res.ok) throw new Error(errorMessage(body, res.status));
      render(body);
    } catch (err) {
      if (err.name === "AbortError") showError("The audit took too long and was stopped. Try again.");
      else if (err instanceof TypeError) showError("Could not reach the server. Is the backend running?");
      else showError(err.message);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  }

  // ---------- events ----------
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const url = $("url").value.trim();
    if (!url) {
      errorBox.hidden = true;
      showError("Enter a website address to audit, for example yourbrand.com.");
      $("url").focus();
      return;
    }
    const payload = { url };
    const toneValue = $("tone").value.trim();
    const guidelines = $("guidelines").value.trim();
    const keywords = $("keywords").value.split(",").map((k) => k.trim()).filter(Boolean).slice(0, 20);
    if (toneValue) payload.brand_tone = toneValue;
    if (guidelines) payload.guidelines = guidelines;
    if (keywords.length) payload.keywords = keywords;
    request("/audit", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    }, LOADING_STEPS);
  });

  sampleBtn.addEventListener("click", () => request("/api/sample", {}, ["Loading the sample audit..."]));

  exampleBtn.addEventListener("click", () => {
    $("tone").value = EXAMPLE_RULES.tone;
    $("keywords").value = EXAMPLE_RULES.keywords;
    $("guidelines").value = EXAMPLE_RULES.guidelines;
  });

  fetch("/api/status").then((r) => r.json()).then((s) => {
    statusEl.textContent = s.ai_configured ? "Live audits on" : "Demo mode: add an API key for live audits";
    statusEl.classList.add(s.ai_configured ? "live" : "demo");
  }).catch(() => { statusEl.textContent = "Server not reachable"; });
})();
